# Add the bin directory to the path, if needed.
if ! echo ${PATH} | /bin/grep -q /usr/jawa/bin ; then
        PATH=${PATH}:/usr/jawa/bin
fi

# If a MANPATH is set, we need to add our man page
# directory to the list. If a MANPATH is not set,
# man should automatically find our man pages.
if [ -n "${MANPATH}" ]; then
        if ! echo ${MANPATH} | /bin/grep -q /usr/share/man ; then
                export MANPATH=${MANPATH}:/usr/share/man
        fi
fi
